Maria Deslis | Nicola Hetrck | Anastasia Shpurik
fall2013 | csci445 | rader

This project, Moon Tetris, is definitely worth 100 pts. 

Here's why:
We made profound use of canvas tag.
CSS3 features: custom font, text shadow, multiple background images (with permission from Professor Rader).
Cool Javascript libraries: The power of Math!

Mainly we deserve an A because we spent 16+ hours on this project.
And we created tetris, with awesome new moon-physics features.

Difficulties: 
-We tried to get an image to rotate in one spot, but it kept rotating across he screen and no amount of Google
searching was able to fix this issue!
-Rotating tetrimino pieces
-Having tetriminos overlap other pieces
-Clearing a line and then having board shift downwards
-Getting left and right background images to not collide if browser windown decreased
-Preventing default action of up and down keys AKA scrolling (Zoom out if needed!)


How to Play MOON TETRIS:
	- Press Space to start game
	- Up arrow rotates the piece
	- Right and Left arrows move the piece accordingly
	- You are on the Moon, so board does not shift once line is cleared
Tips for playing MOON TETRIS:
	- If you move a piece too quickly, phantom pieces will appear, and you must remember which pieces are phantom and which aren't
	- At any point in time, some pieces may disappear - will you be the lucky one?
	- Zoom Out if the screen has a scroll bar!

Note: Getting 5 lines cleared is a EXCELLENT score! 

